﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinalProjectWindows
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        [System.Runtime.InteropServices.DllImport("User32.DLL", EntryPoint = "ReleaseCapture")]

        private extern static void ReleaseCapture();

        [System.Runtime.InteropServices.DllImport("User32.DLL", EntryPoint = "SendMessage")]
        private extern static void SendMessage(System.IntPtr hWnd, int wMsg, int wPram, int lParamn);

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string validUsername = "admin";
            string validPassword = "Leah123";

            string username = txtUsername.Text;
            string password = txtPassword.Text;

            if (username == validUsername && password == validPassword)
            {
                DataList dl = new DataList();
                dl.Show();
                this.Hide();
            }
            else
            {
                if (username != validUsername)
                {
                    lblUserChk.Visible = true;
                    txtUsername.Focus();
                }
                if (password != validPassword)
                {
                    lblPassChk.Visible = true;
                    txtPassword.Focus();
                }
            }
        }

        private void txtUsername_TextChanged_1(object sender, EventArgs e)
        {
            txtUsername.ForeColor = Color.Black;
            lblUserChk.Visible = false;
        }

        private void txtPassword_TextChanged_1(object sender, EventArgs e)
        {
            txtPassword.ForeColor = Color.Black;
            txtPassword.PasswordChar = '*';

            lblPassChk.Visible = false;
        }
    }
}
