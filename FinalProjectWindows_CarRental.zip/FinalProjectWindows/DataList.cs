﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinalProjectWindows
{
    public partial class DataList : Form
    {
        private static readonly HttpClient client = new HttpClient();

        public DataList()
        {
            InitializeComponent();
        }

        private async void DataList_Load(object sender, EventArgs e)
        {
            
        }

       

        private void btnGetALL_Click_1(object sender, EventArgs e)
        {
            // Await the asynchronous method to get car data
            var cars = await GetCarsAsync();
            if (cars != null)
            {
                // Bind the retrieved car data to the DataGridView
                dgvList.DataSource = cars;
            }
        }

        private async Task<List<Car>> GetCarsAsync()
        {
            try
            {
                string url = "http://localhost:5137/api/Car"; // Replace with your actual API URL
                var response = await client.GetStringAsync(url);
                return Newtonsoft.Json.JsonConvert.DeserializeObject<List<Car>>(response);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error fetching data: {ex.Message}");
                return null;
            }
        }
    }

    // Define the Car class to match the JSON structure returned by the API
    public class Car
    {
        public int Id { get; set; }
        public string Brand { get; set; }
        public string Model { get; set; }
        public int Year { get; set; }
        public decimal DailyRate { get; set; }

    }
}
